import processing.core.*; 

import processing.opengl.*; 
import damkjer.ocd.*; 
import processing.opengl.*; 
import javax.media.opengl.*; 
import org.jblas.*; 

import org.jblas.benchmark.*; 
import org.jblas.util.*; 
import org.jblas.*; 
import org.jblas.exceptions.*; 
import org.jblas.ranges.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class Fourspace extends PApplet {

 /**
 * Fourspace 
 * by Chris Johnson-Roberson
 *
 * projection algorithm from "Four-Space Visualization of 4D Objects" <http://steve.hollasch.net/thesis/> (Hollasch 1991)
 * native matrix math routines from <http://jblas.org>
 *
 */






PGraphicsOpenGL pgl;
GL gl;

ArrayList faces, labels;
Cell[] cells;
float S, T, scale;
float[] from, from3D, cameraFrom, to, up, over, aimAt;
float[] attitude = {
  0.0f, 0.0f, 0.0f
};
FloatMatrix V, Va, Vb, Vc, Wa, Wb, Wc, Wd;
FloatMatrix fromColumnVector, fromRowVector, fromColumnVector4D, fromRowVector4D;
FloatMatrix toMatrix, upMatrix, overMatrix, transform, transform4D, pt1, pt2;
FloatMatrix xwMatrix, ywMatrix, zwMatrix;
int depthCue = color(255, 255, 255);
float centerX, centerY, viewAngle, defaultTheta, lastXWtheta, lastYWtheta, lastZWtheta, radius = 1.0f;
float interocularAngle = -0.03509f;
int steps = 10;
String proj_type;
Camera cam1, cam2, camAxes;
PGraphics hud;
PImage img;
int opacity = 0x44FFFFFF;
PFont font;

String modelName = "8-cell (hypercube)";

boolean camsInitialized = false;
boolean stereo = false;
boolean panning = false;
boolean facesActive = true, normalsActive = false, axesActive = false;
boolean labelsActive = false, namesActive = false;
boolean faceLabels = true, cellLabels = false, vertexLabels = false, vertexCoordLabels = false, fps = false, helpActive = true;
boolean lockTo4DViewpoint = false;
boolean depthCueing = true, hiddenVolumeRemoval = false;
boolean rotXW = false, rotYW = false, rotZW = false;

String[] helpText = new String[] { 
  "h or ?: show/hide help", 
  "mouse: drag to rotate, alt/cmd-click to pan, mousewheel to zoom",
  "1-7: choose geometry", 
  "x, y, z: rotate counterclockwise in XW, YW, ZW plane", "X, Y, Z: rotate clockwise", 
  "r: reset", 
  "k: lock to 4D viewpoint",
  "i: show/hide names", 
  "a: show/hide axes", "f: show/hide faces", "l: show/hide labels", "n: show/hide normals", 
  "p: parallel/perspective projection", 
  "v: show/hide hidden volumes", "d: depth cueing on/off", 
  ",: increase opacity", ".: decrease opacity", 
  "<space>: stereo on/off", "=: increase interocular angle", "-: decrease interocular angle",
  "ESC: exit"
};


public void setup() {
  size(screenWidth, screenHeight, OPENGL);
  // if Processing 1.5:
  // size(screen.width, screen.height, OPENGL);
  
  font = createFont("Monaco", 12);
  textFont(font);

  proj_type = "PERSPECTIVE";
  centerX = width/2.0f;
  centerY = height/2.0f;
  viewAngle = radians(45);
  labels = new ArrayList<Label>();

  lastXWtheta = 0;
  lastYWtheta = 0;
  lastZWtheta = 0;
  scale = 1.0f;
  S = 1.0f;
  from = new float[] {    // 4D viewpoint
    1, 4, 0, 0
  };

  cameraFrom = new float[3];
  cameraFrom[0] = from[0];
  cameraFrom[1] = from[1];
  cameraFrom[2] = from[2];
  to = new float[] {    // 4D focus point
    0, 0, 0, 0
  };
  aimAt = new float[] {  // 3D camera focus
    0, 0, 0
  };
  up = new float[] { 
    0, 1, 0, 0
  };
  over = new float[] {
    0, 0, 1, 0
  };
  fromColumnVector4D = new FloatMatrix(from);
  fromRowVector4D = fromColumnVector4D.dup().reshape(1, 4);


  toMatrix = new FloatMatrix(to).dup();
  upMatrix = new FloatMatrix(up).dup();
  overMatrix = new FloatMatrix(over).dup();

  faces = new ArrayList<Face3>();
  cells = genFromVEFCfile("data/8cell_vefc.txt");    // default to 8-cell (hypercube)

  transform4D = Calc4Matrix(fromColumnVector4D, toMatrix, upMatrix, overMatrix);
  project4Dcells();
  cam1 = new Camera(this, cameraFrom[0], cameraFrom[1], cameraFrom[2], aimAt[0], aimAt[1], aimAt[2], radians(45), (float) 1.0f*width/height, 0.001f, 20);
  cam2 = new Camera(this, cameraFrom[0], cameraFrom[1], cameraFrom[2], aimAt[0], aimAt[1], aimAt[2], radians(45), (float) 1.0f*width/height, 0.001f, 20);
  camAxes = new Camera(this, cameraFrom[0], cameraFrom[1], cameraFrom[2], aimAt[0], aimAt[1], aimAt[2], radians(45), (float) 1.0f*width/height, 0.001f, 20);
  camsInitialized = true;

  addMouseWheelListener(new java.awt.event.MouseWheelListener() { 
    public void mouseWheelMoved(java.awt.event.MouseWheelEvent evt) { 
      mouseWheel(evt.getWheelRotation());
    }
  }
  );
}

public void draw() {
  background(0);
  noLights();
  stroke(255);

  pgl = (PGraphicsOpenGL) g;
  gl = pgl.gl;


  if (labelsActive || helpActive || namesActive) labels.clear();
  if (stereo) {
    gl.glViewport(0, 0, width/2, height);
  }
  cam1.feed();
  drawCells();

  if (stereo) {
    gl.glViewport(width/2, 0, width/2, height); 
    cam2.feed();
    drawCells();
  }

  hint(DISABLE_DEPTH_TEST);
  if (labelsActive || helpActive || namesActive) drawLabels();
  if (axesActive) project4Daxes();

  if (rotXW || rotYW || rotZW) {
    if (rotXW) rotateXW(defaultTheta);
    if (rotYW) rotateYW(defaultTheta);
    if (rotZW) rotateZW(defaultTheta);

    transform4D = Calc4Matrix(fromColumnVector4D, toMatrix, upMatrix, overMatrix);

    if (lockTo4DViewpoint) {
      FloatMatrix temp = project4Dvector(fromColumnVector4D);
      float pos[] = cam1.position();
      float newX = pos[0] + (temp.get(0) - pos[0])/60;
      float newY = pos[1] + (temp.get(1) - pos[1])/60;
      float newZ = pos[2] + (temp.get(2) - pos[2])/60;

      cam1.jump(newX, newY, newZ);
      if (stereo) {
        cam2.jump(newX, newY, newZ);
        cam1.circle(interocularAngle);
        cam2.circle(-interocularAngle);
      }
    }
    project4Dcells();
  }
}

public void drawCells() {
  if (normalsActive) {
    for (Cell cell : cells) {
      drawCellNormal(cell);
    }
  }
  if (cells.length > 1) {
    for (Cell cell : cells) {
      if (labelsActive && cellLabels) addLabels(cell);
      if (cell.visible) {
        for (Face face: cell.faces) {
          face.faceColor = cell.cellColor;
        }
      }
    }
  }
  int i = 0;
  radius = 1.0f;
  Iterator faceItr = faces.iterator();
  while (faceItr.hasNext ()) {
    Face3 face = (Face3) faceItr.next();
    if (!face.parentCellVisible && hiddenVolumeRemoval) continue;
    if (facesActive && !depthCueing) fill(opacity & face.faceColor);
    else noFill();
    beginShape();
    ListIterator itr = face.vertices.listIterator();
    while (itr.hasNext ()) {
      FloatMatrix vert = (FloatMatrix) itr.next();
      int thisI = itr.previousIndex();
      int nextI = itr.nextIndex();
      if (depthCueing) {
        if (facesActive) fill(opacity & (int)(Integer) face.colors.get(thisI));
        stroke((int)(Integer) face.colors.get(thisI));
      }
      else {
        stroke(face.faceColor);
      }
      vertex(vert.get(0), vert.get(1), vert.get(2));
    }
    endShape(CLOSE);
    i++;
    if (labelsActive) addLabels(face);
    //    if (normalsActive) drawCellNormal(face.vertices, face.normal);
  }
}


public void cameraRecenter() {
  if (camsInitialized) {
    cam1.aim(aimAt[0], aimAt[1], aimAt[2]);
    cam2.aim(aimAt[0], aimAt[1], aimAt[2]);
  }
}

public void project4Daxes() {
  String p = proj_type;
  proj_type = "PARALLEL";
  gl.glViewport(width-80, height - 80, 80, 80);
  camAxes.feed();
  float pos[] = cam1.position();
  camAxes.jump(pos[0], pos[1], pos[2]);
  FloatMatrix temp = project4Dvector(toMatrix);
  camAxes.aim(temp.get(0), temp.get(1), temp.get(2));

  for (Cell cell : genAxes()) {
    for (Face face : cell.faces) {
      Iterator itr = face.vertices.iterator();
      stroke(face.faceColor);
      beginShape(LINES);
      while (itr.hasNext ()) {
        FloatMatrix vert = (FloatMatrix) itr.next();
        vert = project4Dvector(vert);
        vertex(vert.get(0), vert.get(1), vert.get(2));
      }
      endShape();
    }
  }
  proj_type = p;
}

public FloatMatrix project4Dvector(FloatMatrix vec) {
  FloatMatrix newVec = new FloatMatrix(3);
  if (proj_type == "PARALLEL") S = 1.0f; // kludge; should be 1/radius around to-point
  else T = 1 / tan(viewAngle/2);
  pt1 = vec.dup().reshape(1, 4).sub(fromRowVector4D).mmul(transform4D).reshape(4, 1).sub(fromColumnVector4D);
  if (proj_type == "PERSPECTIVE") {
    float w = pt1.dot(Wd);
    if (pt1.norm2() > radius) radius = pt1.norm2();
    depthCue = color((int) ((w/radius)*256));
    S = T / w;
  }
  newVec.put(0, S * pt1.dot(Wa));
  newVec.put(1, S * pt1.dot(Wb));
  newVec.put(2, S * pt1.dot(Wc));
  return newVec;
}


public void project4Dcells() {
  faces.clear();
  if (proj_type == "PARALLEL") S = 1.0f; // kludge; should be 1/radius around to-point
  else T = 1 / tan(viewAngle/2);

  pt1 = toMatrix.dup().reshape(1, 4).sub(fromRowVector4D).mmul(transform4D).reshape(4, 1).sub(fromColumnVector4D);
  if (proj_type == "PERSPECTIVE") {
    S = T / pt1.dot(Wd);
  }
  aimAt[0] = S * pt1.dot(Wa);
  aimAt[1] = S * pt1.dot(Wb);
  aimAt[2] = S * pt1.dot(Wc);

  cameraRecenter();
  for (Cell cell : cells) {
    cell.normal = cellNormal(cell);
    if (cells.length > 1) cellIsVisible(cell);
    else cell.visible = true;
    for (Face face : cell.faces) {
      ArrayList<FloatMatrix> projectedVerts = new ArrayList<FloatMatrix>();
      ArrayList theseColors = new ArrayList();
      Iterator vitr = face.vertices.iterator();
      while (vitr.hasNext ()) {
        FloatMatrix vert = (FloatMatrix) vitr.next();
        projectedVerts.add(project4Dvector(vert));
        if (proj_type == "PERSPECTIVE") theseColors.add(blendColor(depthCue, face.faceColor, MULTIPLY));
        else theseColors.add(face.faceColor);
      }
      faces.add(new Face3(projectedVerts, face.vertices, face.numberedVertices, face.faceNum, face.faceColor, theseColors, cell.visible));
    }
  }
}




public void keyPressed() {
  if (key == '-') {
    interocularAngle -= 0.01f;
    cam1.circle(0.01f);
    cam2.circle(-0.01f);
  }
  if (key == '=') {
    interocularAngle += 0.01f;
    cam1.circle(-0.01f);
    cam2.circle(0.01f);
  }

//  if (key == '-' || key == '=') {
//    println(interocularAngle);
//  }


  if (key == 'a') {
    axesActive = !axesActive;
  }
  if (key == 'v') {
    hiddenVolumeRemoval = !hiddenVolumeRemoval;
  }
  if (key == 'd') {
    depthCueing = !depthCueing;
  }


  if (key == ',') {
    int currentOpacity = ((opacity >> 24) & 0xFF);
    currentOpacity = constrain(currentOpacity - 16, 1, 255);
    opacity = currentOpacity << 24 | 0x00FFFFFF;
  }

  if (key == '.') {
    int currentOpacity = ((opacity >> 24) & 0xFF);
    currentOpacity = constrain(currentOpacity + 16, 1, 255);
    opacity = currentOpacity << 24 | 0x00FFFFFF;
  }

  if (key == 'x' || key == 'y' || key == 'z') {
    if (key == 'x') {
      rotXW = !rotXW;
    }

    if (key == 'y') {
      rotYW = !rotYW;
    }
    if (key == 'z') {
      rotZW = !rotZW;
    }
    defaultTheta = 0.01f;
  }

  if (key == 'X' || key == 'Y' || key == 'Z') {
    if (key == 'X') {
      rotXW = !rotXW;
    }

    if (key == 'Y') {
      rotYW = !rotYW;
    }
    if (key == 'Z') {
      rotZW = !rotZW;
    }
    defaultTheta = -0.01f;
  }

  if (key == 'r') {
    rotXW = rotYW = rotZW = false;
    fromColumnVector4D = new FloatMatrix(from);
    fromRowVector4D = fromColumnVector4D.dup().reshape(1, 4);
    toMatrix = new FloatMatrix(to).dup();
    upMatrix = new FloatMatrix(up).dup();
    overMatrix = new FloatMatrix(over).dup();

    transform4D = Calc4Matrix(fromColumnVector4D, toMatrix, upMatrix, overMatrix);
    cam1.jump(from[0], from[1], from[2]);
    cam1.aim(aimAt[0], aimAt[1], aimAt[2]);
    if (stereo) {
      cam2.jump(from[0], from[1], from[2]);
      cam2.aim(aimAt[0], aimAt[1], aimAt[2]);
      cam1.circle(interocularAngle);
      cam2.circle(-interocularAngle);
    }
    project4Dcells();
  }


  if (key == 'f') {
    facesActive = !facesActive;
  }
  if (key == 'l') {
    labelsActive = !labelsActive;
  }
  if (key == 'k') {
    lockTo4DViewpoint = !lockTo4DViewpoint;
  }
  if (key == 'i') {
    namesActive = !namesActive;
  }
  if (key == 'N') {
    normalsActive = !normalsActive;
  }
  if (key == 'h' || key == '/' || key == '?') {
    helpActive = !helpActive;
  }
  if (key == 'p') {
    if (proj_type == "PARALLEL") proj_type = "PERSPECTIVE";
    else proj_type = "PARALLEL";
    project4Dcells();
  }
  if (key == ' ') {
    stereo = !stereo;
    if (stereo) {
      float[] pos = cam1.position();
      cam2.jump(pos[0], pos[1], pos[2]);
      cam2.aim(aimAt[0], aimAt[1], aimAt[2]);
      cam1.circle(-interocularAngle);
      cam2.circle(interocularAngle);
    }
  }

  if (key == '1' || key == '2' || key == '3' || key == '4' || key == '5' || key == '6' || key == '7') {
    loadNewModel(PApplet.parseInt(str(key)));
  }

  if (key == CODED) {
    if (keyCode == 157 || keyCode == 18) {  // holding command/alt key
      panning = true;
    }
  }
}

public void keyReleased() {
  if (key == CODED) {
    if (keyCode == 157 || keyCode == 18) {   // release command key
      panning = false;
    }
  }
}

public void mouseDragged() {
  if (panning) {
    float mul = -0.001f;
    float[] pos = cam1.position();
    float[] target = cam1.target();
    mul *= sqrt(pow(target[0]-pos[0], 2) + pow(target[1]-pos[1], 2) + pow(target[2]-pos[2], 2));
    cam1.track((mouseX - pmouseX)*mul, (mouseY - pmouseY)*mul);
    if (stereo) cam2.track((mouseX - pmouseX)*mul, (mouseY - pmouseY)*mul);
    //    if (axesActive) camAxes.track((mouseX - pmouseX)*mul, (mouseY - pmouseY)*mul);
  }
  else {
    cam1.tumble(-radians(mouseX - pmouseX), -radians(mouseY - pmouseY));
    if (stereo) cam2.tumble(-radians(mouseX - pmouseX), -radians(mouseY - pmouseY));
    //    if (axesActive) camAxes.tumble(-radians(mouseX - pmouseX), -radians(mouseY - pmouseY));
  }
}


public void loadNewModel(int i) {
  switch (i) {
  case 1:
    cells = genAxes();
    modelName = "axes";
    break;
  case 2:
    cells = genFromVEFCfile("data/5cell_vefc.txt");
    modelName = "5-cell (hyperpyramid)";
    break;
  case 3:
    cells = genFromVEFCfile("data/8cell_vefc.txt");
    modelName = "8-cell (hypercube)";
    break;
  case 4:
    cells = genFromVEFCfile("data/16cell_vefc.txt");
    modelName = "16-cell (hyperoctahedron)";
    break;
  case 5:
    cells = genFromVEFCfile("data/24cell_vefc.txt");
    modelName = "24-cell";
    break;
  case 6:
    cells = genFromVEFCfile("data/120cell_vefc.txt");
    modelName = "120-cell";
    break;
  case 7:
    cells = genFromVEFCfile("data/600cell_vefc.txt");
    modelName = "600-cell";    
    break;
  }

  project4Dcells();
}

public void addLabels(Cell cell) {
  FloatMatrix temp = (FloatMatrix) cell.vertices.get(0).dup();
  for (int j = 1; j < cell.vertices.size(); j++) {
    temp.addi((FloatMatrix) cell.vertices.get(j));
  }
  temp.divi(cell.vertices.size());
  String label = str(cell.cellNum);
  FloatMatrix temp2 = project4Dvector(temp);
  labels.add(new Label(label, myScreenX(temp2.get(0), temp2.get(1), temp2.get(2)), myScreenY(temp2.get(0), temp2.get(1), temp2.get(2)), cell.cellColor));
}

public void addLabels(Face3 face) {
  FloatMatrix temp = (FloatMatrix) face.vertices.get(0).dup();
  for (int j = 1; j < face.vertices.size(); j++) {
    temp.addi((FloatMatrix) face.vertices.get(j));
  }
  temp.divi(face.vertices.size());

  ListIterator itr = face.vertices.listIterator();
  while (itr.hasNext ()) {
    FloatMatrix vert3 = (FloatMatrix) itr.next();
    FloatMatrix vert4 = (FloatMatrix) face.oldVertices.get(itr.previousIndex());
    String label = str(face.faceNum);

    if (faceLabels) labels.add(new Label(label, myScreenX(temp.get(0), temp.get(1), temp.get(2)), myScreenY(temp.get(0), temp.get(1), temp.get(2)), face.faceColor));
    label = str((int) face.numberedVertices.get(itr.previousIndex()));
    float x = myScreenX(vert3.get(0), vert3.get(1), vert3.get(2));
    float y = myScreenY(vert3.get(0), vert3.get(1), vert3.get(2));
    if (vertexLabels) labels.add(new Label(label, x, y));
    if (vertexCoordLabels) {
      label = "(";
      label += nf(vert4.get(0), 1, 2) + ", ";
      label += nf(vert4.get(1), 1, 2) + ", ";
      label += nf(vert4.get(2), 1, 2) + ", ";
      label += nf(vert4.get(3), 1, 2) + ")";
      labels.add(new Label(label, x, y));
    }
  }
}

public void drawLabels() {
  camera();
  ortho(0, width, 0, height, -10, 10);

  if (fps) labels.add(new Label(nf(frameRate, 2, 2), width - 40, 10, color(255)));

  if (helpActive) {
    int i = 20;
    for (String h : helpText) {
      labels.add(new Label(h, 10, i, color(255)));
      i += 10;
    }
  }

  if (namesActive) {
    labels.add(new Label(modelName, width/2 - (modelName.length() * 4), 10, color(255)));
  }

  Iterator itr = labels.iterator();
  while (itr.hasNext ()) {
    Label l = (Label) itr.next();
    fill(l.labelColor);
    l.draw();
  }
}


public void cellIsVisible(Cell cell) {
  FloatMatrix temp = (FloatMatrix) cell.vertices.get(0).dup();
  for (int j = 1; j < cell.vertices.size(); j++) {
    temp.addi((FloatMatrix) cell.vertices.get(j));
  }
  temp.divi(cell.vertices.size());
  float thisResult = fromColumnVector4D.dup().sub(temp).dot(cell.normal);
  if (thisResult < 0) {
    cell.visible = false;
  }
  else {
    cell.visible = true;
  }
}

public void drawCellNormal(Cell cell) {
  FloatMatrix temp = (FloatMatrix) cell.vertices.get(0).dup();
  for (int j = 1; j < cell.vertices.size(); j++) {
    temp.addi((FloatMatrix) cell.vertices.get(j));
  }
  temp.divi(cell.vertices.size());


  ArrayList<FloatMatrix> normal3D = new ArrayList<FloatMatrix>();
  normal3D.add(project4Dvector(temp));
  normal3D.add(project4Dvector(cell.normal.dup().add(temp)));

  int thisColor = cell.cellColor;
  float thisResult = fromColumnVector4D.dup().sub(temp).dot(cell.normal);
  if (thisResult < 0) {
    thisColor = color(255, 0, 0);  // cell normal is pointing away from camera
  }
  stroke(thisColor);

  beginShape(LINES);
  vertex(normal3D.get(0).get(0), normal3D.get(0).get(1), normal3D.get(0).get(2));
  vertex(normal3D.get(1).get(0), normal3D.get(1).get(1), normal3D.get(1).get(2));
  endShape();
}


public void mousePressed() {
  if (mouseEvent.getClickCount()==2) {
    cam1.jump(cameraFrom[0], cameraFrom[1], cameraFrom[2]);
    if (stereo) {
      cam1.circle(-interocularAngle);
      cam2.jump(cameraFrom[0], cameraFrom[1], cameraFrom[2]);
      cam2.circle(interocularAngle);
    }
    cameraRecenter();
  }
}
public void mouseWheel(int delta) {
  cam1.dolly(delta/5.0f);
  cam1.aim(aimAt[0], aimAt[1], aimAt[2]);
  if (stereo) {
    cam2.dolly(delta/5.0f);
    cam2.aim(aimAt[0], aimAt[1], aimAt[2]);
  }
}

public float myScreenX(float x, float y, float z) {
  float ax = pgl.modelview.m00 * x + pgl.modelview.m01 * y + pgl.modelview.m02 * z + pgl.modelview.m03;
  float ay = pgl.modelview.m10 * x + pgl.modelview.m11 * y + pgl.modelview.m12 * z + pgl.modelview.m13;
  float az = pgl.modelview.m20 * x + pgl.modelview.m21 * y + pgl.modelview.m22 * z + pgl.modelview.m23;
  float aw = pgl.modelview.m30 * x + pgl.modelview.m31 * y + pgl.modelview.m32 * z + pgl.modelview.m33;

  float ox = pgl.projection.m00 * ax + pgl.projection.m01 * ay + pgl.projection.m02 * az + pgl.projection.m03 * aw;
  float ow = pgl.projection.m30 * ax + pgl.projection.m31 * ay + pgl.projection.m32 * az + pgl.projection.m33 * aw;

  if (ow != 0) {
    ox /= ow;
  }
  float sx = width * (1 + ox) / 2.0f;
  return sx;
}


public float myScreenY(float x, float y, float z) {        
  float ax = pgl.modelview.m00 * x + pgl.modelview.m01 * y + pgl.modelview.m02 * z + pgl.modelview.m03;
  float ay = pgl.modelview.m10 * x + pgl.modelview.m11 * y + pgl.modelview.m12 * z + pgl.modelview.m13;
  float az = pgl.modelview.m20 * x + pgl.modelview.m21 * y + pgl.modelview.m22 * z + pgl.modelview.m23;
  float aw = pgl.modelview.m30 * x + pgl.modelview.m31 * y + pgl.modelview.m32 * z + pgl.modelview.m33;

  float oy = pgl.projection.m10 * ax + pgl.projection.m11 * ay + pgl.projection.m12 * az + pgl.projection.m13 * aw;
  float ow = pgl.projection.m30 * ax + pgl.projection.m31 * ay + pgl.projection.m32 * az + pgl.projection.m33 * aw;

  if (ow != 0) {
    oy /= ow;
  }    
  float sy = height * (1 + oy) / 2.0f;
  // Inverting result because of Processing' inverted Y axis.
  sy = height - sy;
  return sy;
}

// data structures for storing 4D volumes

class Cell {
  Face[] faces;
  ArrayList<FloatMatrix> vertices;
  FloatMatrix normal;
  int cellColor;
  int cellNum;
  boolean visible;

  Cell(ArrayList<Face> theseFaces) {
    this(theseFaces, -1, color(255, 255, 255));
  }
  Cell(ArrayList<Face> theseFaces, int number, int thisColor) {
    vertices = new ArrayList<FloatMatrix>();
    normal = new FloatMatrix(4);
    faces = new Face[theseFaces.size()];
    cellNum = number;
    Iterator itr = theseFaces.iterator();
    int i = 0;
    while (itr.hasNext ()) {
      Face face = (Face) itr.next();
      faces[i] = face;
      vertices.addAll(face.vertices);
      i++;
    }
    cellColor = thisColor;
    visible = true;
  }
}

class Face {
  ArrayList<FloatMatrix> vertices;
  ArrayList<Edge> edges;
  ArrayList<Integer> numberedVertices;
  int faceNum;
  int faceColor;


  Face(Collection theseVertices) {
    this(theseVertices, color(255, 255, 255));
  }
  Face(Collection theseVertices, Collection numVerts) {
    this(theseVertices, numVerts, -1, color(255, 255, 255));
  }
  Face(Collection theseVertices, int thisColor) {
    vertices = new ArrayList<FloatMatrix>();
    vertices.addAll(theseVertices);
    numberedVertices = new ArrayList<Integer>();
    for (int i =0; i < vertices.size(); i ++) {
      numberedVertices.add(i);
    }
    faceNum = -1;
    faceColor = thisColor;
  }
  Face(Collection theseVertices, Collection numVerts, int num) {
    vertices = new ArrayList<FloatMatrix>();
    vertices.addAll(theseVertices);
    numberedVertices = new ArrayList<Integer>();
    numberedVertices.addAll(numVerts);
    faceNum = num;
  }

  Face(Collection theseVertices, Collection numVerts, int num, int thisColor) {
    vertices = new ArrayList<FloatMatrix>();
    vertices.addAll(theseVertices);
    numberedVertices = new ArrayList<Integer>();
    numberedVertices.addAll(numVerts);
    faceColor = thisColor;
    faceNum = num;
  }
}

class Edge {
  ArrayList<FloatMatrix> vertices;

  Edge(FloatMatrix _start, FloatMatrix _end) {
    vertices = new ArrayList<FloatMatrix>();
    vertices.add(_start);
    vertices.add(_end);
  }
}

class Face3 {
  ArrayList<FloatMatrix> vertices;
  ArrayList<FloatMatrix> oldVertices;
  ArrayList<FloatMatrix> normal3D;
  ArrayList colors;
  int faceColor;
  ArrayList<Integer> numberedVertices;
  int faceNum;
  boolean parentCellVisible;

  Face3(Collection verts, Collection oldVerts, Collection numVerts, int numOfFaces, int thisColor, ArrayList theseColors, boolean visible) {
    vertices = new ArrayList<FloatMatrix>();
    vertices.addAll(verts);
    oldVertices = new ArrayList<FloatMatrix>();
    oldVertices.addAll(oldVerts);
    faceNum = numOfFaces;
    colors = new ArrayList();
    colors.addAll(theseColors);
    numberedVertices = new ArrayList<Integer>();
    numberedVertices.addAll(numVerts);
    faceColor = thisColor;
    parentCellVisible = visible;
  }
}

class Label {
  String labelText;
  float x, y;
  int labelColor;

  Label(String _text, float _x, float _y) {
    this(_text, _x, _y, color(255));
  }
  Label(String _text, float _x, float _y, int thisColor) {
    labelText = _text;
    x = _x;
    y = _y;
    labelColor = thisColor;
  }

  public void draw() {
    text(labelText, x, y, -1);
  }
}

int[] colorRandom = new int[] {
  color(255, 0, 0), color(0, 255, 0), color(0, 0, 255), color(255, 255, 0), color(255, 0, 255), color(0, 255, 255)
};

// or, uncomment for all white
// color[] colorRandom = new color[]{color(255,255,255)};

public Cell[] genAxes() {  // generate a basic set of 4D axes
  ArrayList<Face> faces = new ArrayList<Face>();
  Cell[] result = new Cell[1];
  FloatMatrix[] verts = new FloatMatrix[] {
    new FloatMatrix(new float[] {
      0, 0, 0, 0
    }
    ), 
    new FloatMatrix(new float[] {
      1, 0, 0, 0
    }
    ), 
    new FloatMatrix(new float[] {
      0, 1, 0, 0
    }
    ), 
    new FloatMatrix(new float[] {
      0, 0, 1, 0
    }
    ), 
    new FloatMatrix(new float[] {
      0, 0, 0, 1
    }
    )
    };

  int[] colors = new int[] {
    color(255, 0, 0), color(0, 255, 0), color(0, 0, 255), color(255, 255, 255)
  };

  for (int i = 1; i < 5; i++) { 
    ArrayList<FloatMatrix> edge = new ArrayList<FloatMatrix>();
    edge.add(verts[0]);
    edge.add(verts[i]);
    faces.add(new Face(edge, colors[i-1]));
  }
  result[0] = new Cell(faces);
  return result;
}

public Cell[] genFromVEFCfile(String filename) {    // load from comma-separated VEFC data file
  ArrayList<FloatMatrix> vertices = new ArrayList<FloatMatrix>();
  ArrayList<Edge> edges = new ArrayList<Edge>();
  ArrayList<Face> faces = new ArrayList<Face>();
  ArrayList<Cell> cells = new ArrayList<Cell>();

  String lines[] = loadStrings(filename);
  String mode = "V"; // V(ertices), E(dges), F(aces), or C(ells)
  int numOfFaces = 0;
  int numOfCells = 0;
  for (int i = 0; i < lines.length; i++) {
    if (lines[i].length() < 3) {
      mode = trim(lines[i]);
      continue;
    }   
    String colorOptions[] = split(lines[i], "; "); // if color has been specified, the line will have a semicolon
    String components[] = split(colorOptions[0], ", ");

    if (mode.equals("V")) {      // vertices
      float[] thisCoords = new float[4];
      thisCoords[0] = PApplet.parseFloat(components[0]);
      thisCoords[1] = PApplet.parseFloat(components[1]);
      thisCoords[2] = PApplet.parseFloat(components[2]);
      thisCoords[3] = PApplet.parseFloat(components[3]);
      vertices.add(new FloatMatrix(thisCoords));
    }

    if (mode.equals("E")) {    //  edges (currently these are not used for anything...)
      edges.add(new Edge(vertices.get(PApplet.parseInt(components[0])), vertices.get(PApplet.parseInt(components[1]))));
    }
    if (mode.equals("F")) {    // faces
      ArrayList<FloatMatrix> theseVertices = new ArrayList<FloatMatrix>();
      ArrayList<Integer> numVerts = new ArrayList<Integer>();

      for (int j = 1; j < components.length; j++) {
        numVerts.add((Integer) PApplet.parseInt(components[j]));
        theseVertices.add(vertices.get(PApplet.parseInt(components[j])));
      }

      //    used to set colors by hex values, e.g. "0, 1, 2; FF336699" (AARRGGBB)
      int thisColor = colorRandom[numOfFaces % colorRandom.length];
      if (colorOptions.length > 1) {
        thisColor = color(unhex(colorOptions[1]));
      }


      faces.add(new Face(theseVertices, numVerts, numOfFaces, thisColor));
      numOfFaces++;
    }

    if (mode.equals("C")) {  // cells
      ArrayList<Face> theseFaces = new ArrayList<Face>();
      for (int j = 0; j < components.length; j++) {
        theseFaces.add(faces.get(PApplet.parseInt(components[j])));
      }
      int thisColor = colorRandom[numOfCells % colorRandom.length];
      if (colorOptions.length > 1) {
        thisColor = color(unhex(colorOptions[1]));
      }
      Cell thisCell = new Cell(theseFaces, numOfCells, thisColor);
      cells.add(thisCell);
      for (Face face: thisCell.faces) {
        face.faceColor = thisCell.cellColor;
      } 
      numOfCells++;
    }
  }
  if (cells.size() == 0) cells.add(new Cell(faces));

  Cell[] result = new Cell[cells.size()];
  for (int j = 0; j < cells.size(); j++) {
    result[j] = (Cell) cells.get(j);
  }

  // display stats
  //  println(str(cells.size()) + " cells, " + str(faces.size()) + " faces, "+ str(edges.size()) + " edges, " + str(vertices.size()) + " vertices");
  return result;
}

public FloatMatrix Calc4Matrix(FloatMatrix from, FloatMatrix to, FloatMatrix up, FloatMatrix over) {
  float norm;
  FloatMatrix cameraTransform;
  Wd = to.sub(from);

  norm = Wd.norm2();
  if (norm == 0) {
    println("To point and From point are the same.");
  }
  Wd.muli(1/norm);

  Wa = cross4(up, over, Wd);
  norm = Wa.norm2();
  if (norm == 0) {
    println("Invalid Up vector.");
  }
  Wa.muli(1/norm);

  Wb = cross4(over, Wd, Wa);
  norm = Wb.norm2();
  if (norm == 0) {
    println("Invalid Over vector.");
  }
  Wb.muli(1/norm);

  Wc = cross4(Wd, Wa, Wb);
  FloatMatrix step1 = Wa.concatHorizontally(Wa, Wb);
  FloatMatrix step2 = Wa.concatHorizontally(step1, Wc);


  return step2.concatHorizontally(step2, Wd);
}

public FloatMatrix cross3(FloatMatrix a, FloatMatrix b) {
  FloatMatrix product = new FloatMatrix(3);
  product.put(0, a.get(1)*b.get(2) - a.get(2)*b.get(1));
  product.put(1, a.get(2)*b.get(0) - a.get(0)*b.get(2));
  product.put(2, a.get(0)*b.get(1) - a.get(1)*b.get(0));
  return product;
}

public FloatMatrix cross4(FloatMatrix U, FloatMatrix V, FloatMatrix W) {
  float A, B, C, D, E, F;
  FloatMatrix result = new FloatMatrix(4);
  A = (V.get(0) * W.get(1)) - (V.get(1) * W.get(0));
  B = (V.get(0) * W.get(2)) - (V.get(2) * W.get(0));
  C = (V.get(0) * W.get(3)) - (V.get(3) * W.get(0));
  D = (V.get(1) * W.get(2)) - (V.get(2) * W.get(1));
  E = (V.get(1) * W.get(3)) - (V.get(3) * W.get(1));
  F = (V.get(2) * W.get(3)) - (V.get(3) * W.get(2));

  // Calculate the result-vector components.

  result.put(0, (U.get(1) * F) - (U.get(2) * E) + (U.get(3) * D));
  result.put(1, (U.get(0) * F) + (U.get(2) * C) - (U.get(3) * B));
  result.put(2, (U.get(0) * E) - (U.get(1) * C) + (U.get(3) * A));
  result.put(3, -(U.get(0) * D) + (U.get(1) * B) - (U.get(2) * A));

  return result;
}

public void rotateXW(float theta) {
  if (theta != lastXWtheta) {
    xwMatrix = FloatMatrix.eye(4);
    xwMatrix.put(0, 0, cos(theta));
    xwMatrix.put(3, 3, cos(theta));
    xwMatrix.put(0, 3, sin(theta));
    xwMatrix.put(3, 0, -1*sin(theta));
    lastXWtheta = theta;
  }
  fromRowVector4D.mmuli(xwMatrix);
  fromColumnVector4D = fromRowVector4D.dup().reshape(4, 1);
  upMatrix.reshape(1, 4).mmuli(xwMatrix).reshape(4, 1);
  overMatrix.reshape(1, 4).mmuli(xwMatrix).reshape(4, 1);
}
public void rotateYW(float theta) {
  if (theta != lastYWtheta) {
    ywMatrix = FloatMatrix.eye(4);
    ywMatrix.put(1, 1, cos(theta));
    ywMatrix.put(3, 3, cos(theta));
    ywMatrix.put(1, 3, sin(theta));
    ywMatrix.put(3, 1, -1*sin(theta));
    lastYWtheta = theta;
  }
  fromRowVector4D.mmuli(ywMatrix);
  fromColumnVector4D = fromRowVector4D.dup().reshape(4, 1);
  upMatrix.reshape(1, 4).mmuli(ywMatrix).reshape(4, 1);
  overMatrix.reshape(1, 4).mmuli(ywMatrix).reshape(4, 1);
}
public void rotateZW(float theta) {
  if (theta != lastZWtheta) {
    zwMatrix = FloatMatrix.eye(4);
    zwMatrix.put(2, 2, cos(theta));
    zwMatrix.put(3, 3, cos(theta));
    zwMatrix.put(2, 3, sin(theta));
    zwMatrix.put(3, 2, -1*sin(theta));
    lastZWtheta = theta;
  }
  fromRowVector4D.mmuli(zwMatrix);
  fromColumnVector4D = fromRowVector4D.dup().reshape(4, 1);
  upMatrix.reshape(1, 4).mmuli(zwMatrix).reshape(4, 1);
  overMatrix.reshape(1, 4).mmuli(zwMatrix).reshape(4, 1);
}

public FloatMatrix[] gramSchmidt(FloatMatrix[] vecs) {
  FloatMatrix u[] = new FloatMatrix[vecs.length];
  for (int i = 0; i < vecs.length; i++) {
    u[i] = vecs[i].dup();
    for (int j = 0; j < i; j++) {
      u[i].subi(u[j].mul(vecs[i].dot(u[j])/u[j].dot(u[j])));
    }
    u[i].divi(u[i].norm2());
  }
  return u;
}

public FloatMatrix cellNormal(Cell cell) {
  FloatMatrix temp = (FloatMatrix) cell.vertices.get(0).dup();
  for (int j = 1; j < cell.vertices.size(); j++) {
    temp.addi((FloatMatrix) cell.vertices.get(j));
  }
  temp.divi(cell.vertices.size());

  ArrayList<FloatMatrix> normal = new ArrayList<FloatMatrix>();
  
  FloatMatrix v[] = new FloatMatrix[3];
  for (int i = 0; i < 3; i++) {
    v[i] = cell.vertices.get(i).dup().sub(temp);
  }
  FloatMatrix vecs[] = gramSchmidt(v);

  FloatMatrix d = cross4(vecs[0], vecs[1], vecs[2]);
  float norm = d.norm2();
  d.muli(1/norm);
  
  return d;
}

  static public void main(String args[]) {
    PApplet.main(new String[] { "--present", "--bgcolor=#000000", "--hide-stop", "Fourspace" });
  }
}
